// ============================================
// HOME PAGE - LIVE DATA (RMS + Freq + Tilt + Raw)
// ============================================

const NODE_IDS = ['node_01', 'node_02'];
const seen = { node_01: false, node_02: false };
// Payload terakhir per node + mode tampil (raw / calibrated)
const latest = { node_01: null, node_02: null };
const view = { accel: 'raw', gyro: 'raw' };

function setEl(id, v, digits, suffix) {
    const el = document.getElementById(id);
    if (!el) return;
    if (v == null || isNaN(v)) { el.textContent = '--'; return; }
    el.textContent = Number(v).toFixed(digits) + (suffix || '');
}

function applyPayload(p) {
    const idx = NODE_IDS.indexOf(p && p.node_id);
    if (idx === -1) return;
    const n = idx + 1;
    const a = p.accelerometer, g = p.gyroscope;
    latest[p.node_id] = p;

    // RMS
    setEl(`rms-n${n}`, p.vibration && p.vibration.rms, 3);
    // Tilt (delta dari baseline — 0 setelah recalibrate)
    setEl(`tilt-n${n}-roll`, p.tilt && p.tilt.roll_delta, 1, '\u00B0');
    setEl(`tilt-n${n}-pitch`, p.tilt && p.tilt.pitch_delta, 1, '\u00B0');

    // Raw accel/gyro
    setEl(`acc-n${n}-x`, a && a.x, 3);
    setEl(`acc-n${n}-y`, a && a.y, 3);
    setEl(`acc-n${n}-z`, a && a.z, 3);
    setEl(`gyro-n${n}-x`, g && g.x, 2);
    setEl(`gyro-n${n}-y`, g && g.y, 2);
    setEl(`gyro-n${n}-z`, g && g.z, 2);

    // Render ulang kartu sesuai mode tampil (raw/calibrated)
    renderAxes('accel', 'acc');
    renderAxes('gyro', 'gyro');

    // Node status: ONLINE + SAMP
    if (!seen[p.node_id]) {
        seen[p.node_id] = true;
        const badge = document.getElementById(`badge-n${n}`);
        if (badge) { badge.textContent = 'ONLINE'; badge.className = 'badge'; badge.style.background = 'var(--green-soft)'; badge.style.color = 'var(--green)'; }
    }
    if (p.sampling_rate_hz) {
        const samp = document.getElementById('samp');
        if (samp) samp.textContent = `${p.sampling_rate_hz}Hz`;
    }
}

// mode: 'accel' | 'gyro' → sumber data raw vs calibrated
function axisSource(mode) {
    if (view[mode] === 'raw') return { tag: 'RAW', data: mode === 'accel' ? 'accelerometer' : 'gyroscope' };
    return {
        tag: 'CAL',
        data: mode === 'accel' ? 'accelerometer_calibrated' : 'gyroscope_calibrated'
    };
}

function renderAxes(mode, idPrefix) {
    const { tag, data } = axisSource(mode);
    const tagEl = document.getElementById(`tag-${mode}`);
    if (tagEl) tagEl.textContent = tag;
    for (const id of NODE_IDS) {
        const p = latest[id];
        const src = p && p[data];
        const n = NODE_IDS.indexOf(id) + 1;
        setEl(`${idPrefix}-n${n}-x`, src && src.x, mode === 'accel' ? 3 : 2);
        setEl(`${idPrefix}-n${n}-y`, src && src.y, mode === 'accel' ? 3 : 2);
        setEl(`${idPrefix}-n${n}-z`, src && src.z, mode === 'accel' ? 3 : 2);
    }
}

function toggleAxes(mode) {
    view[mode] = view[mode] === 'raw' ? 'cal' : 'raw';
    renderAxes(mode, mode === 'accel' ? 'acc' : 'gyro');
}

async function fetchLatest() {
    for (const id of NODE_IDS) {
        try {
            const rows = await api(`/api/readings/${id}?limit=1`);
            if (Array.isArray(rows) && rows.length) applyPayload(rows[0]);
            const fft = await api(`/api/fft/${id}?limit=1`);
            if (Array.isArray(fft) && fft.length) {
                const map = { node_01: 1, node_02: 2 };
                setEl(`freq-n${map[id]}`, fft[0].dominant_freq, 1);
            }
        } catch (_) { /* backend belum jalan / belum ada data */ }
    }
}

// Kalibrasi accel semua node
async function recalibrateAll() {
    const btn = document.getElementById('btnRecalibrate');
    if (!btn) return;
    const orig = btn.innerHTML;
    btn.querySelector('.mini-val').textContent = '...';
    try {
        const res = await Promise.all(NODE_IDS.flatMap(id =>
            ['recalibrate', 'calibrate_accel'].map(action =>
                fetch(`/api/node/${id}/action`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ action }),
                }).catch(() => null)
            )
        ));
        const ok = res.some(r => r && r.ok);
        btn.querySelector('.mini-val').textContent = ok ? 'OK' : 'Gagal';
    } catch (_) {
        btn.querySelector('.mini-val').textContent = 'Gagal';
    }
    setTimeout(() => { btn.innerHTML = orig; }, 1500);
}

// Total sampel time-series tersimpan (FR-01)
async function refreshQuality() {
    try {
        const results = await Promise.all(NODE_IDS.map(id => api(`/api/quality/${id}`)));
        const total = results.reduce((sum, q) => sum + (q?.total_samples || 0), 0);
        const dup = results.reduce((sum, q) => sum + (q?.duplicates || 0), 0);
        const gap = results.reduce((sum, q) => sum + (q?.gaps || 0), 0);
        setEl('samples-total', total, 0);
        const stat = document.getElementById('stat-samples');
        if (stat) stat.title = `Duplikat: ${dup}, Gap: ${gap}`;
    } catch (_) { /* backend belum jalan */ }
}

// Reset tampilan: data lama tetap di DB, yang tampil hanya data baru setelah ini
async function resetDataView() {
    if (!confirm('Reset tampilan data?\nData lama tetap tersimpan di database.\nYang tampil hanya data baru mulai sekarang.')) return;
    try {
        const r = await fetch('/api/reset', { method: 'POST' });
        const j = await r.json();
        if (!j.ok) throw new Error('reset gagal');
        // Muat ulang → nilai '--', badge OFFLINE, terisi lagi dari data baru via WS
        location.reload();
    } catch (_) {
        alert('Reset gagal — cek koneksi backend.');
    }
}

document.addEventListener('DOMContentLoaded', function () {
    fetchLatest();
    refreshQuality();
    setInterval(refreshQuality, 5000);
    connectWS(applyPayload);
    document.getElementById('resetData')?.addEventListener('click', resetDataView);
    document.getElementById('btnRecalibrate')?.addEventListener('click', recalibrateAll);
    document.getElementById('btn-accel')?.addEventListener('click', () => toggleAxes('accel'));
    document.getElementById('btn-gyro')?.addEventListener('click', () => toggleAxes('gyro'));
});
